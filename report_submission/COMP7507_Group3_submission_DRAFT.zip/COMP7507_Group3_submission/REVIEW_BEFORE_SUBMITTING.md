# COMP7507 Group 3 — Pre-Submission Review Checklist

This submission package was generated from the verified frozen datasets bundled in `proj/final_report/`, live captures of all five refactored dashboards, the project proposal, GitHub PR history (`#1`–`#9`), and the COMP7507 Final Report rubrics.

## Before Final Moodle Upload
1. **Fill in reserved AI disclosures (`proj/report/draft_sources/ai_usage_report.html`, Page 5):**
   - Early Proposal Stage (Huang Shan lead; all five members discussed & revised)
   - Chapter 1 (Ruan Lixin)
   - Chapter 2 (Qi Yingying)
   - Chapter 3 (Wong Yan Yuet)
   - Chapter 4 (Wang Ling)
2. **Confirm Part II Individual Contributions (`proj/report/draft_sources/final_report.html`, Pages 14–18):**
   - Each member confirms their task attribution, key findings, and reflection statement.
3. **Rebuild final PDFs and ZIP:**
   - Run `bash proj/report/draft_sources/rebuild_pdfs.sh` (draft mode) or `bash proj/report/draft_sources/rebuild_pdfs.sh --final` (clean submission filenames without `_draft` / `_DRAFT`).
4. **End-to-end smoke test on the unzipped archive:**
   - Open root `index.html` in a browser and click every link.
   - Visually check both PDFs (`Part I` = 12 body pages ≤ 20 max; `Part II` = 1 page/member ≤ 5 max).
   - Run `cd work_package && bash start.sh` and confirm `http://127.0.0.1:8764/` serves the Storyboard and all 5 dashboards cleanly.
